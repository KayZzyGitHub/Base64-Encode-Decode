[![forthebadge made-with-javascript](http://ForTheBadge.com/images/badges/made-with-javascript.svg)](///)


# Base64 | Encrypt / Decrypt

Base64 | Encrypt / Decrypt , a pour but de vous faciliter la tache via un simple script en javascript !

## 🛠 Installation

```txt
Lancé le install.bat
```
## 💻 Utilisation
```txt
Lancé le start.bat
```

## 📚 Crédit
https://github.com/ElKxsumi

![kayzzykasumi;](https://img.shields.io/badge/KayZzy-Kasumi;-ff69b4.svg)
